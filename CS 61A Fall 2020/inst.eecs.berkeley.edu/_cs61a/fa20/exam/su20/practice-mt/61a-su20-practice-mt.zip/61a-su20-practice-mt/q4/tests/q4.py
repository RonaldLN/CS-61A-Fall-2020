test = {'name': 'q4',
 'points': 6,
 'suites': [{'cases': [{'code': '>>> sums(2, 2)\n'
                                '[[1, 1]]\n'
                                '\n'
                                '>>> sums(2, 3)\n'
                                '[]\n'
                                '\n'
                                '>>> sums(4, 2)\n'
                                '[[3, 1], [2, 2], [1, 3]]\n'
                                '\n'
                                '>>> sums(5, 3)\n'
                                '[[3, 1, 1], [2, 2, 1], [1, 3, 1], [2, 1, 2], '
                                '[1, 2, 2], [1, 1, 3]]\n'}],
             'scored': True,
             'setup': 'from q4 import *',
             'type': 'doctest'}]}