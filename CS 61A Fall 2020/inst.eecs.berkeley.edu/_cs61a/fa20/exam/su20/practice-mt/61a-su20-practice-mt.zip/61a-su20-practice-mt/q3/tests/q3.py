test = {'name': 'q3',
 'points': 6,
 'suites': [{'cases': [{'code': '>>> close(123)\n'
                                '123\n'
                                '\n'
                                '>>> close(153)\n'
                                '153\n'
                                '\n'
                                '>>> close(1523)\n'
                                '153\n'
                                '\n'
                                '>>> close(15123)\n'
                                '1123\n'
                                '\n'
                                '>>> close(11111111)\n'
                                '11\n'
                                '\n'
                                '>>> close(985357)\n'
                                '557\n'
                                '\n'
                                '>>> close(14735476)\n'
                                '143576\n'
                                '\n'
                                '>>> close(812348567)\n'
                                '1234567\n'}],
             'scored': True,
             'setup': 'from q3 import *',
             'type': 'doctest'}]}